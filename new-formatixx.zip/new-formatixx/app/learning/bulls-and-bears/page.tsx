"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { BullsAndBearsContent } from "@/components/learning/bulls-and-bears-content"
import { BullsAndBearsQuiz } from "@/components/learning/bulls-and-bears-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function BullsAndBearsPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.readingMarketLessons.bullsBears.title}
      category={t.learning.section3.subtitle}
      description={t.learning.readingMarketLessons.bullsBears.description}
      ContentComponent={BullsAndBearsContent}
      QuizComponent={BullsAndBearsQuiz}
      nextLesson={{ title: t.common.trends, href: "/learning/understanding-trends" }}
    />
  )
}
