"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { NavigatingChartsContent } from "@/components/learning/navigating-charts-content"
import { NavigatingChartsQuiz } from "@/components/learning/navigating-charts-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function NavigatingChartsPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.readingMarketLessons.navigating.title}
      category={t.learning.section3.subtitle}
      description={t.learning.readingMarketLessons.navigating.description}
      ContentComponent={NavigatingChartsContent}
      QuizComponent={NavigatingChartsQuiz}
      nextLesson={{ title: t.common.bullsBears, href: "/learning/bulls-and-bears" }}
    />
  )
}
