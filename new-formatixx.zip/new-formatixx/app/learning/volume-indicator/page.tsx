"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { VolumeIndicatorContent } from "@/components/learning/volume-indicator-content"
import { VolumeIndicatorQuiz } from "@/components/learning/volume-indicator-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function VolumeIndicatorPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.toolkitLessons.volume.title}
      category={t.learning.section4.subtitle}
      description={t.learning.toolkitLessons.volume.description}
      ContentComponent={VolumeIndicatorContent}
      QuizComponent={VolumeIndicatorQuiz}
      nextLesson={{ title: t.common.movingAverage, href: "/learning/moving-average" }}
    />
  )
}
