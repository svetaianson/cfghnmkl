"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { UnderstandingTrendsContent } from "@/components/learning/understanding-trends-content"
import { UnderstandingTrendsQuiz } from "@/components/learning/understanding-trends-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function UnderstandingTrendsPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.readingMarketLessons.trends.title}
      category={t.learning.section3.subtitle}
      description={t.learning.readingMarketLessons.trends.description}
      ContentComponent={UnderstandingTrendsContent}
      QuizComponent={UnderstandingTrendsQuiz}
      nextLesson={{ title: t.common.support, href: "/learning/support-and-resistance" }}
    />
  )
}
