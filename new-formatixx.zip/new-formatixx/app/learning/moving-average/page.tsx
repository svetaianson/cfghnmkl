"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { MovingAverageContent } from "@/components/learning/moving-average-content"
import { MovingAverageQuiz } from "@/components/learning/moving-average-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function MovingAveragePage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.toolkitLessons.movingAverage.title}
      category={t.learning.section4.subtitle}
      description={t.learning.toolkitLessons.movingAverage.description}
      ContentComponent={MovingAverageContent}
      QuizComponent={MovingAverageQuiz}
      nextLesson={{ title: t.common.rsi, href: "/learning/rsi" }}
    />
  )
}
