"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { LanguageBinaryContent } from "@/components/learning/language-binary-content"
import { LanguageBinaryQuiz } from "@/components/learning/language-binary-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function LanguageBinaryPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.moneyMakers.language.title}
      category={t.learning.section2.subtitle}
      description={t.learning.moneyMakers.language.description}
      ContentComponent={LanguageBinaryContent}
      QuizComponent={LanguageBinaryQuiz}
      nextLesson={{ title: t.common.fundamentals, href: "/learning/fundamentals-binary" }}
    />
  )
}
