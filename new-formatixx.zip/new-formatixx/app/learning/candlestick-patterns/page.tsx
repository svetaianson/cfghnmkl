"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { CandlestickPatternsContent } from "@/components/learning/candlestick-patterns-content"
import { CandlestickPatternsQuiz } from "@/components/learning/candlestick-patterns-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function CandlestickPatternsPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.readingMarketLessons.candlestick.title}
      category={t.learning.section3.subtitle}
      description={t.learning.readingMarketLessons.candlestick.description}
      ContentComponent={CandlestickPatternsContent}
      QuizComponent={CandlestickPatternsQuiz}
      nextLesson={{ title: t.common.volume, href: "/learning/volume-indicator" }}
    />
  )
}
