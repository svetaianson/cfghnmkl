"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { GoldBinaryContent } from "@/components/learning/gold-binary-content"
import { GoldBinaryQuiz } from "@/components/learning/gold-binary-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function GoldBinaryPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.moneyMakers.gold.title}
      category={t.learning.section2.subtitle}
      description={t.learning.moneyMakers.gold.description}
      ContentComponent={GoldBinaryContent}
      QuizComponent={GoldBinaryQuiz}
      nextLesson={{ title: t.common.stocks, href: "/learning/stocks-vs-binary" }}
    />
  )
}
