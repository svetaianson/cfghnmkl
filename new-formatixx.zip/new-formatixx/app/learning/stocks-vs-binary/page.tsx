"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { StocksVsBinaryContent } from "@/components/learning/stocks-vs-binary-content"
import { StocksVsBinaryQuiz } from "@/components/learning/stocks-vs-binary-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function StocksVsBinaryPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.moneyMakers.stocks.title}
      category={t.learning.section2.subtitle}
      description={t.learning.moneyMakers.stocks.description}
      ContentComponent={StocksVsBinaryContent}
      QuizComponent={StocksVsBinaryQuiz}
      nextLesson={{ title: t.common.crudeOil, href: "/learning/crude-oil-binary" }}
    />
  )
}
