"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { CrudeOilBinaryContent } from "@/components/learning/crude-oil-binary-content"
import { CrudeOilBinaryQuiz } from "@/components/learning/crude-oil-binary-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function CrudeOilBinaryPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.moneyMakers.crudeOil.title}
      category={t.learning.section2.subtitle}
      description={t.learning.moneyMakers.crudeOil.description}
      ContentComponent={CrudeOilBinaryContent}
      QuizComponent={CrudeOilBinaryQuiz}
      nextLesson={{ title: t.common.navigating, href: "/learning/navigating-the-charts" }}
    />
  )
}
