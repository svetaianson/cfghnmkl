"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { RSIContent } from "@/components/learning/rsi-content"
import { RSIQuiz } from "@/components/learning/rsi-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function RSIPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.toolkitLessons.rsi.title}
      category={t.learning.section4.subtitle}
      description={t.learning.toolkitLessons.rsi.description}
      ContentComponent={RSIContent}
      QuizComponent={RSIQuiz}
      nextLesson={{ title: t.learning.toolkit.volume, href: "/learning/volume-indicator" }}
    />
  )
}
