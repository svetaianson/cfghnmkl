"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { TopDownTradingContent } from "@/components/learning/top-down-trading-content"
import { TopDownTradingQuiz } from "@/components/learning/top-down-trading-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function TopDownTradingPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.strategiesLessons.topDown.title}
      category={t.learning.section5.subtitle}
      description={t.learning.strategiesLessons.topDown.description}
      ContentComponent={TopDownTradingContent}
      QuizComponent={TopDownTradingQuiz}
      nextLesson={{ title: t.common.strategyExample, href: "/learning/strategy-example" }}
    />
  )
}
