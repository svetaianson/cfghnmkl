"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { ChartPatternsContent } from "@/components/learning/chart-patterns-content"
import { ChartPatternsQuiz } from "@/components/learning/chart-patterns-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function ChartPatternsPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.readingMarketLessons.patterns.title}
      category={t.learning.section3.subtitle}
      description={t.learning.readingMarketLessons.patterns.description}
      ContentComponent={ChartPatternsContent}
      QuizComponent={ChartPatternsQuiz}
      nextLesson={{ title: t.common.candlestick, href: "/learning/candlestick-patterns" }}
    />
  )
}
