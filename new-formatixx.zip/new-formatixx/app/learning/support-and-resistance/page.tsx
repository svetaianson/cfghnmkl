"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { SupportAndResistanceContent } from "@/components/learning/support-and-resistance-content"
import { SupportAndResistanceQuiz } from "@/components/learning/support-and-resistance-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function SupportAndResistancePage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.readingMarketLessons.support.title}
      category={t.learning.section3.subtitle}
      description={t.learning.readingMarketLessons.support.description}
      ContentComponent={SupportAndResistanceContent}
      QuizComponent={SupportAndResistanceQuiz}
      nextLesson={{ title: t.common.patterns, href: "/learning/chart-patterns" }}
    />
  )
}
