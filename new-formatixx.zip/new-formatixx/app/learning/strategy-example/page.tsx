"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { StrategyExampleContent } from "@/components/learning/strategy-example-content"
import { StrategyExampleQuiz } from "@/components/learning/strategy-example-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function StrategyExamplePage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.strategiesLessons.strategyExample.title}
      category={t.learning.section5.subtitle}
      description={t.learning.strategiesLessons.strategyExample.description}
      ContentComponent={StrategyExampleContent}
      QuizComponent={StrategyExampleQuiz}
      nextLesson={{ title: t.common.buyingSelling, href: "/learning/buying-and-selling" }}
    />
  )
}
