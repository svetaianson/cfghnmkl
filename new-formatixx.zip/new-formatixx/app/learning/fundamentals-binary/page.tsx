"use client"

import { LessonLayout } from "@/components/learning/lesson-layout"
import { FundamentalsBinaryContent } from "@/components/learning/fundamentals-binary-content"
import { FundamentalsBinaryQuiz } from "@/components/learning/fundamentals-binary-quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export default function FundamentalsBinaryPage() {
  const { t } = useLanguage()

  return (
    <LessonLayout
      title={t.learning.moneyMakers.fundamentals.title}
      category={t.learning.section2.subtitle}
      description={t.learning.moneyMakers.fundamentals.description}
      ContentComponent={FundamentalsBinaryContent}
      QuizComponent={FundamentalsBinaryQuiz}
      nextLesson={{ title: t.common.gold, href: "/learning/gold-binary" }}
    />
  )
}
