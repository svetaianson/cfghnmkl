"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function StrategyExampleContent() {
  const { t } = useLanguage()
  const s = t.learning.strategiesLessons.strategyExample.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.maCrossover}</h2>
        <p className="text-white/80 text-base leading-relaxed">{s.intro1}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.strategySetup}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.setupIntro}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.fastMA}</span> {s.fastMAVal}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.slowMA}</span> {s.slowMAVal}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.timeframe}</span> {s.timeframeVal}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.confirmation}</span> {s.confirmationVal}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.entryRules}</h2>
        <div className="space-y-4">
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
            <h3 className="font-semibold text-white mb-2">{s.buySignal}</h3>
            <ul className="space-y-1 text-sm text-white/80">
              <li>{s.buyStep1}</li>
              <li>{s.buyStep2}</li>
              <li>{s.buyStep3}</li>
              <li>{s.buyStep4}</li>
            </ul>
          </div>
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
            <h3 className="font-semibold text-white mb-2">{s.sellSignal}</h3>
            <ul className="space-y-1 text-sm text-white/80">
              <li>{s.sellStep1}</li>
              <li>{s.sellStep2}</li>
              <li>{s.sellStep3}</li>
              <li>{s.sellStep4}</li>
            </ul>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.riskManagement}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.riskIntro}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.stopLoss}</span> {s.stopLossVal}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.takeProfit}</span> {s.takeProfitVal}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.positionSize}</span> {s.positionSizeVal}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.exitSignal}</span> {s.exitSignalVal}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.realWorldExample}</h2>
        <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4 space-y-2 text-sm">
          <p className="text-white/80"><span className="font-semibold text-white">{s.exPair}</span></p>
          <p className="text-white/80"><span className="font-semibold text-white">{s.exDate}</span></p>
          <p className="text-white/80"><span className="font-semibold text-white">{s.exEntry}</span></p>
          <p className="text-white/80"><span className="font-semibold text-white">{s.exSL}</span></p>
          <p className="text-white/80"><span className="font-semibold text-white">{s.exTP}</span></p>
          <p className="text-green-400 font-semibold">{s.exResult}</p>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyTakeaways}</h2>
        <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
          <ul className="space-y-2 text-white/80">
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway1}</li>
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway2}</li>
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway3}</li>
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway4}</li>
          </ul>
        </div>
      </Card>
    </div>
  )
}
