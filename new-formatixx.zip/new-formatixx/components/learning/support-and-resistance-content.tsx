"use client"

import { useLanguage } from "@/lib/i18n/language-context"

export function SupportAndResistanceContent() {
  const { t } = useLanguage()
  const s = t.learning.readingMarketLessons.support.sections

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{s.supportResistance}</h2>
        <p className="text-white/80 leading-relaxed mb-4">{s.intro}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.whatIsSupport}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.supportDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.whatIsResistance}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.resistanceDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.roleReversal}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.roleReversalDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.identifying}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.identifyingDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.trading}</h3>
        <p className="text-white/80 leading-relaxed">{s.tradingDesc}</p>
      </section>
    </div>
  )
}
