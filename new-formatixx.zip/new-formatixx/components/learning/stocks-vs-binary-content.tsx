"use client"

import { Card } from "@/components/ui/card"
import { Check } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function StocksVsBinaryContent() {
  const { t } = useLanguage()
  const content = t.learning.moneyMakers.stocks.sections

  const differences = [
    { category: content.cat1, binary: content.cat1Binary, stocks: content.cat1Stocks },
    { category: content.cat2, binary: content.cat2Binary, stocks: content.cat2Stocks },
    { category: content.cat3, binary: content.cat3Binary, stocks: content.cat3Stocks },
    { category: content.cat4, binary: content.cat4Binary, stocks: content.cat4Stocks },
    { category: content.cat5, binary: content.cat5Binary, stocks: content.cat5Stocks },
    { category: content.cat6, binary: content.cat6Binary, stocks: content.cat6Stocks },
  ]

  const binaryBenefits = [
    content.binaryBenefit1,
    content.binaryBenefit2,
    content.binaryBenefit3,
    content.binaryBenefit4,
  ]

  const stockBenefits = [
    content.stockBenefit1,
    content.stockBenefit2,
    content.stockBenefit3,
    content.stockBenefit4,
  ]

  return (
    <div className="space-y-8">
      {/* Introduction */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.difference}</h2>
        <p className="text-white/70 leading-relaxed">
          {content.intro}
        </p>
      </section>

      {/* Key Differences */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-6">{content.keyDifferences}</h2>
        <div className="space-y-4">
          {differences.map((item, index) => (
            <Card key={index} className="bg-purple-900/20 border-purple-500/30 p-5 overflow-hidden">
              <h3 className="text-lg font-semibold text-purple-400 mb-4">{item.category}</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4">
                  <h4 className="text-green-400 font-semibold mb-2">{content.binaryOptions}</h4>
                  <p className="text-white/60 text-sm">{item.binary}</p>
                </div>
                <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
                  <h4 className="text-blue-400 font-semibold mb-2">{content.stocksLabel}</h4>
                  <p className="text-white/60 text-sm">{item.stocks}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Which Is Better */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.whichBetter}</h2>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <p className="text-white/70 leading-relaxed mb-6">
            {content.whichBetterIntro}
          </p>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-5">
              <h4 className="text-green-400 font-semibold mb-3">{content.chooseBinary}</h4>
              <ul className="space-y-2">
                {binaryBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-2 text-white/60 text-sm">
                    <Check className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-5">
              <h4 className="text-blue-400 font-semibold mb-3">{content.chooseStocks}</h4>
              <ul className="space-y-2">
                {stockBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-2 text-white/60 text-sm">
                    <Check className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      </section>

      {/* Remember */}
      <section>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <p className="text-purple-300 font-medium">
            {content.remember}
          </p>
        </Card>
      </section>
    </div>
  )
}
