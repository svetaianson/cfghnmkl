"use client"

import { useLanguage } from "@/lib/i18n/language-context"

export function ReadyForRealTradingContent() {
  const { t } = useLanguage()
  const s = t.learning.levelUpLessons.readyForReal.sections

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{s.mainTitle}</h2>
        <p className="text-white/80 leading-relaxed mb-4">{s.intro}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.consistentProfitability}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.consistentProfitabilityDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.solidRisk}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.solidRiskDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.tradingPlan}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.tradingPlanDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.emotionalControl}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.emotionalControlDesc}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.financialReadiness}</h3>
        <p className="text-white/80 leading-relaxed">{s.financialReadinessDesc}</p>
      </section>
    </div>
  )
}
