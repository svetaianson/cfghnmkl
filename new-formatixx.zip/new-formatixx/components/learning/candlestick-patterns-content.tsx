"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function CandlestickPatternsContent() {
  const { t } = useLanguage()
  const s = t.learning.readingMarketLessons.candlestick.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.artOfReading}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.intro1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.intro2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.anatomy}</h2>
        <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-5 mb-4">
          <div className="space-y-3">
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.body}</span> {s.bodyDesc}
            </p>
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.wicks}</span> {s.wicksDesc}
            </p>
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.upperWick}</span> {s.upperWickDesc}
            </p>
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.lowerWick}</span> {s.lowerWickDesc}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.bullishReversal}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.bullishReversalIntro}</p>
        <div className="space-y-4">
          <div className="bg-green-600/10 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-green-300 mb-2">{s.hammer}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.hammerDesc}</p>
          </div>
          <div className="bg-green-600/10 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-green-300 mb-2">{s.bullishEngulfing}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.bullishEngulfingDesc}</p>
          </div>
          <div className="bg-green-600/10 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-green-300 mb-2">{s.morningStar}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.morningStarDesc}</p>
          </div>
          <div className="bg-green-600/10 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-green-300 mb-2">{s.piercingLine}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.piercingLineDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.bearishReversal}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.bearishReversalIntro}</p>
        <div className="space-y-4">
          <div className="bg-red-600/10 border border-red-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-red-300 mb-2">{s.shootingStar}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.shootingStarDesc}</p>
          </div>
          <div className="bg-red-600/10 border border-red-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-red-300 mb-2">{s.bearishEngulfing}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.bearishEngulfingDesc}</p>
          </div>
          <div className="bg-red-600/10 border border-red-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-red-300 mb-2">{s.eveningStar}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.eveningStarDesc}</p>
          </div>
          <div className="bg-red-600/10 border border-red-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-red-300 mb-2">{s.darkCloud}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.darkCloudDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.indecision}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.indecisionIntro}</p>
        <div className="space-y-4">
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.doji}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.dojiDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.spinningTop}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.spinningTopDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.tradingCandlesticks}</h2>
        <div className="space-y-3 mb-4">
          {[
            { label: s.contextCritical, desc: s.contextCriticalDesc },
            { label: s.confirmPattern, desc: s.confirmPatternDesc },
            { label: s.combineWithTrend, desc: s.combineWithTrendDesc },
            { label: s.setStops, desc: s.setStopsDesc },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
              <p className="text-white/80 text-base leading-relaxed">
                <span className="text-purple-300 font-semibold">{item.label}</span> {item.desc}
              </p>
            </div>
          ))}
        </div>
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-xl p-6 mt-4">
          <p className="text-white text-base leading-relaxed font-medium">{s.masterTip}</p>
        </div>
      </Card>
    </div>
  )
}
