"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function TopDownTradingContent() {
  const { t } = useLanguage()
  const s = t.learning.strategiesLessons.topDown.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.whatIsTopDown}</h2>
        <p className="text-white/80 text-base leading-relaxed">{s.intro1}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.threeStepProcess}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.threeStepIntro}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.step1Title}</span> {s.step1Desc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.step2Title}</span> {s.step2Desc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.step3Title}</span> {s.step3Desc}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.benefits}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.benefitsIntro}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.benefit1Title}</span> {s.benefit1Desc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.benefit2Title}</span> {s.benefit2Desc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.benefit3Title}</span> {s.benefit3Desc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.benefit4Title}</span> {s.benefit4Desc}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.practicalExample}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.practicalExampleIntro}</p>
        <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4 space-y-3">
          <p className="text-white/80 text-base leading-relaxed"><span className="font-semibold text-white">{s.exWeekly}</span></p>
          <p className="text-white/80 text-base leading-relaxed"><span className="font-semibold text-white">{s.exDaily}</span></p>
          <p className="text-white/80 text-base leading-relaxed"><span className="font-semibold text-white">{s.ex4H}</span></p>
          <p className="text-white/80 text-base leading-relaxed"><span className="font-semibold text-white">{s.ex1H}</span></p>
          <p className="text-green-400 font-semibold">{s.exResult}</p>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyTakeaways}</h2>
        <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
          <ul className="space-y-2 text-white/80">
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway1}</li>
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway2}</li>
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway3}</li>
            <li className="flex items-start gap-2"><span className="text-green-400">&#10003;</span> {s.takeaway4}</li>
          </ul>
        </div>
      </Card>
    </div>
  )
}
