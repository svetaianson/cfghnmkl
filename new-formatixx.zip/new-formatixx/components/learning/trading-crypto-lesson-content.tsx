"use client"

import { Card } from "@/components/ui/card"
import { Bitcoin, Clock, TrendingUp, Newspaper, Droplets, AlertTriangle, Shield } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function TradingCryptoLessonContent() {
  const { t } = useLanguage()
  const s = t.learning.levelUpLessons.tradingCrypto.sections

  return (
    <div className="space-y-6">
      <Card className="border border-orange-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
            <Bitcoin className="w-5 h-5 text-orange-500" />
          </div>
          <h2 className="text-xl font-bold text-white">{s.whatAre}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.whatAreP1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.whatAreP2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyDifferences}</h2>

        <div className="space-y-4">
          <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-cyan-500" />
              <h3 className="text-lg font-semibold text-white">{s.market247}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.market247Desc}</p>
          </div>

          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-red-500" />
              <h3 className="text-lg font-semibold text-white">{s.higherVolatility}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.higherVolatilityDesc}</p>
          </div>

          <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Newspaper className="w-5 h-5 text-purple-500" />
              <h3 className="text-lg font-semibold text-white">{s.differentDrivers}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.differentDriversDesc}</p>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Droplets className="w-5 h-5 text-yellow-500" />
              <h3 className="text-lg font-semibold text-white">{s.liquidityVariations}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.liquidityVariationsDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.popularPairs}</h2>

        <div className="space-y-3">
          <div className="bg-white/5 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-1">{s.btcusd}</h3>
            <p className="text-white/60 text-sm">{s.btcusdDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-1">{s.ethusd}</h3>
            <p className="text-white/60 text-sm">{s.ethusdDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-1">{s.btceur}</h3>
            <p className="text-white/60 text-sm">{s.btceurDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-1">{s.ethbtc}</h3>
            <p className="text-white/60 text-sm">{s.ethbtcDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-green-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
            <Shield className="w-5 h-5 text-green-500" />
          </div>
          <h2 className="text-xl font-bold text-white">{s.riskManagement}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.riskManagementP1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.riskManagementP2}</p>
      </Card>

      <Card className="border border-red-500/50 bg-red-500/10 p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-3">
          <AlertTriangle className="w-6 h-6 text-red-500" />
          <h2 className="text-lg font-bold text-red-400">{s.warning}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed">{s.warningText}</p>
      </Card>
    </div>
  )
}
