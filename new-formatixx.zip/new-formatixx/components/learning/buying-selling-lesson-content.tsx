"use client"

import { Card } from "@/components/ui/card"
import { TrendingUp, TrendingDown, ListOrdered, CheckCircle2 } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function BuyingSellingLessonContent() {
  const { t } = useLanguage()
  const s = t.learning.executeLessons.buyingSelling.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.understandingOrders}</h2>
        <p className="text-white/80 text-base leading-relaxed">
          {s.intro}
        </p>
      </Card>

      <Card className="border border-green-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <h2 className="text-xl font-bold text-white">{s.buyLong}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed mb-4">
          {s.buyLongDesc}
        </p>
        <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 mb-4">
          <p className="text-white font-semibold mb-2">{s.buyExample}</p>
          <ul className="space-y-2 text-white/80">
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full" />
              {s.buyPoint1}
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full" />
              {s.buyPoint2}
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full" />
              {s.buyPoint3}
            </li>
          </ul>
        </div>
      </Card>

      <Card className="border border-red-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
            <TrendingDown className="w-5 h-5 text-red-500" />
          </div>
          <h2 className="text-xl font-bold text-white">{s.sellShort}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed mb-4">
          {s.sellShortDesc}
        </p>
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-4">
          <p className="text-white font-semibold mb-2">{s.sellExample}</p>
          <ul className="space-y-2 text-white/80">
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full" />
              {s.sellPoint1}
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full" />
              {s.sellPoint2}
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full" />
              {s.sellPoint3}
            </li>
          </ul>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
            <ListOrdered className="w-5 h-5 text-purple-500" />
          </div>
          <h2 className="text-xl font-bold text-white">{s.typesOfOrders}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed mb-4">
          {s.typesOfOrdersDesc}
        </p>
        <div className="space-y-3">
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-white font-semibold">{s.marketOrder}</p>
            <p className="text-white/60 text-sm">{s.marketOrderDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-white font-semibold">{s.limitOrder}</p>
            <p className="text-white/60 text-sm">{s.limitOrderDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-white font-semibold">{s.stopOrder}</p>
            <p className="text-white/60 text-sm">{s.stopOrderDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-white font-semibold">{s.stopLoss}</p>
            <p className="text-white/60 text-sm">{s.stopLossDesc}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-white font-semibold">{s.takeProfit}</p>
            <p className="text-white/60 text-sm">{s.takeProfitDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-cyan-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.executingTrade}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.executingTradeDesc}</p>
        <ol className="space-y-2 text-white/80">
          {[s.step1, s.step2, s.step3, s.step4, s.step5, s.step6, s.step7].map((step, idx) => (
            <li key={idx} className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 text-sm font-bold flex-shrink-0">
                {idx + 1}
              </span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </Card>

      <Card className="border border-green-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyTakeaways}</h2>
        <ul className="space-y-3 text-white/80">
          {[s.takeaway1, s.takeaway2, s.takeaway3, s.takeaway4].map((item, idx) => (
            <li key={idx} className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
