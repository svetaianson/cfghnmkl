"use client"

import { Quiz } from "./quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export function FundamentalsBinaryQuiz() {
  const { t } = useLanguage()
  const quiz = t.learning.moneyMakers.fundamentals.quiz

  const quizQuestions = [
    {
      question: quiz.q1,
      options: [quiz.q1o1, quiz.q1o2, quiz.q1o3],
      correctAnswer: 1,
      explanation: quiz.q1a,
    },
    {
      question: quiz.q2,
      options: [quiz.q2o1, quiz.q2o2, quiz.q2o3],
      correctAnswer: 0,
      explanation: quiz.q2a,
    },
    {
      question: quiz.q3,
      options: [quiz.q3o1, quiz.q3o2, quiz.q3o3],
      correctAnswer: 1,
      explanation: quiz.q3a,
    },
  ]

  return <Quiz questions={quizQuestions} />
}
