"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function LanguageBinaryContent() {
  const { t } = useLanguage()
  const content = t.learning.moneyMakers.language.sections

  const terms = [
    { term: content.term1, description: content.term1Desc },
    { term: content.term2, description: content.term2Desc },
    { term: content.term3, description: content.term3Desc },
    { term: content.term4, description: content.term4Desc },
    { term: content.term5, description: content.term5Desc },
    { term: content.term6, description: content.term6Desc },
    { term: content.term7, description: content.term7Desc },
    { term: content.term8, description: content.term8Desc },
    { term: content.term9, description: content.term9Desc },
  ]

  return (
    <div className="space-y-8">
      {/* Introduction */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.terminology}</h2>
        <p className="text-white/70 leading-relaxed">
          {content.intro}
        </p>
      </section>

      {/* Essential Terms */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-6">{content.essentialTerms}</h2>
        <div className="space-y-4">
          {terms.map((item, index) => (
            <Card key={index} className="bg-purple-900/20 border-purple-500/30 p-5">
              <h3 className="text-lg font-semibold text-purple-400 mb-2">{item.term}</h3>
              <p className="text-white/60 text-sm">{item.description}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* Why Terminology Matters */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.whyMatters}</h2>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <p className="text-white/70 leading-relaxed mb-4">
            {content.whyMattersContent1}
          </p>
          <p className="text-white/70 leading-relaxed">
            {content.whyMattersContent2}
          </p>
        </Card>
      </section>
    </div>
  )
}
