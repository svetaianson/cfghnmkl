"use client"

import { Card } from "@/components/ui/card"
import { TrendingUp, Users, DollarSign, Scale, BarChart3 } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function FundamentalsBinaryContent() {
  const { t } = useLanguage()
  const content = t.learning.moneyMakers.fundamentals.sections

  const indicators = [
    { icon: DollarSign, title: content.interestRates, description: content.interestRatesDesc },
    { icon: BarChart3, title: content.gdp, description: content.gdpDesc },
    { icon: Users, title: content.employment, description: content.employmentDesc },
    { icon: TrendingUp, title: content.inflation, description: content.inflationDesc },
    { icon: Scale, title: content.tradeBalance, description: content.tradeBalanceDesc },
  ]

  return (
    <div className="space-y-8">
      {/* Introduction */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.fundamentalAnalysis}</h2>
        <p className="text-white/70 leading-relaxed mb-4">
          {content.intro1}
        </p>
        <p className="text-white/70 leading-relaxed">
          {content.intro2}
        </p>
      </section>

      {/* Key Economic Indicators */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-6">{content.keyIndicators}</h2>
        <div className="space-y-4">
          {indicators.map((item, index) => {
            const Icon = item.icon
            return (
              <Card key={index} className="bg-purple-900/20 border-purple-500/30 p-5">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                    <p className="text-white/60 text-sm">{item.description}</p>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      </section>

      {/* Central Bank Policy */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.centralBank}</h2>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <p className="text-white/70 leading-relaxed mb-4">
            {content.centralBankContent}
          </p>
          <div className="space-y-3">
            <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-4">
              <h4 className="text-green-400 font-semibold mb-1">{content.hawkish}</h4>
              <p className="text-white/60 text-sm">{content.hawkishDesc}</p>
            </div>
            <div className="bg-red-900/30 border border-red-500/30 rounded-lg p-4">
              <h4 className="text-red-400 font-semibold mb-1">{content.dovish}</h4>
              <p className="text-white/60 text-sm">{content.dovishDesc}</p>
            </div>
          </div>
        </Card>
      </section>

      {/* Putting It All Together */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.puttingTogether}</h2>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <p className="text-white/70 leading-relaxed mb-4">
            {content.puttingTogetherContent}
          </p>
          <div className="bg-purple-600/20 rounded-lg p-4 border border-purple-500/30">
            <p className="text-purple-300 font-medium">
              {content.remember}
            </p>
          </div>
        </Card>
      </section>
    </div>
  )
}
