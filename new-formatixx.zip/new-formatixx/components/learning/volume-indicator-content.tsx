"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function VolumeIndicatorContent() {
  const { t } = useLanguage()
  const s = t.learning.toolkitLessons.volume.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.whatIsVolume}</h2>
        <p className="text-white/80 text-base leading-relaxed">{s.intro1}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.whyVolumeMatters}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.whyVolumeDesc}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.trendConfirmation}</span> {s.trendConfirmationDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.reversalSignals}</span> {s.reversalSignalsDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.breakoutValidation}</span> {s.breakoutValidationDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.weakMoves}</span> {s.weakMovesDesc}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.readingVolumeBars}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.readingVolumeDesc}</p>
        <div className="space-y-3">
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-1">{s.tallBars}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.tallBarsDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-1">{s.shortBars}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.shortBarsDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-1">{s.greenBars}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.greenBarsDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-1">{s.redBars}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.redBarsDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.volumeStrategies}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.volumeStrategiesDesc}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.volumeSurge}</span> {s.volumeSurgeDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.climaxVolume}</span> {s.climaxVolumeDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.volumeDryUp}</span> {s.volumeDryUpDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.accumulation}</span> {s.accumulationDesc}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyTakeaways}</h2>
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-xl p-6">
          <ul className="text-white/80 space-y-2 text-base leading-relaxed">
            <li>{s.takeaway1}</li>
            <li>{s.takeaway2}</li>
            <li>{s.takeaway3}</li>
            <li>{s.takeaway4}</li>
          </ul>
        </div>
      </Card>
    </div>
  )
}
