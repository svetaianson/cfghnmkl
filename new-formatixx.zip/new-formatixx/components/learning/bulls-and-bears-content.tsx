"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function BullsAndBearsContent() {
  const { t } = useLanguage()
  const s = t.learning.readingMarketLessons.bullsBears.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.marketSentiment}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.intro1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.intro2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.bullishMarkets}</h2>
        <div className="bg-green-600/10 border border-green-500/20 rounded-xl p-5 mb-4">
          <h3 className="text-lg font-semibold text-green-300 mb-3">{s.whatIsBull}</h3>
          <p className="text-white/80 text-base leading-relaxed">{s.bullDesc}</p>
        </div>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-purple-300">{s.bullCharacteristics}</h3>
          {[s.bullChar1, s.bullChar2, s.bullChar3, s.bullChar4, s.bullChar5].map((char, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-green-500 mt-2 flex-shrink-0" />
              <p className="text-white/80 text-base leading-relaxed">{char}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.bearishMarkets}</h2>
        <div className="bg-red-600/10 border border-red-500/20 rounded-xl p-5 mb-4">
          <h3 className="text-lg font-semibold text-red-300 mb-3">{s.whatIsBear}</h3>
          <p className="text-white/80 text-base leading-relaxed">{s.bearDesc}</p>
        </div>
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-purple-300">{s.bearCharacteristics}</h3>
          {[s.bearChar1, s.bearChar2, s.bearChar3, s.bearChar4, s.bearChar5].map((char, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-red-500 mt-2 flex-shrink-0" />
              <p className="text-white/80 text-base leading-relaxed">{char}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.tradingWithBullsBears}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.tradingIntro}</p>
        <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4 mb-4">
          <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.keyPrinciples}</h3>
          <div className="space-y-2">
            <p className="text-white/80 text-base leading-relaxed">{s.principle1}</p>
            <p className="text-white/80 text-base leading-relaxed">{s.principle2}</p>
            <p className="text-white/80 text-base leading-relaxed">{s.principle3}</p>
          </div>
        </div>
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-xl p-6 mt-4">
          <p className="text-white text-base leading-relaxed font-medium">{s.remember}</p>
        </div>
      </Card>
    </div>
  )
}
