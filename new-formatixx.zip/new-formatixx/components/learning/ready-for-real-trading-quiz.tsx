"use client"

import { Quiz } from "@/components/learning/quiz"
import { useLanguage } from "@/lib/i18n/language-context"

export function ReadyForRealTradingQuiz() {
  const { t } = useLanguage()
  const quiz = t.learning.levelUpLessons.readyForReal.quiz

  const questions = [
    {
      question: quiz.q1,
      options: [quiz.q1o1, quiz.q1o2, quiz.q1o3, quiz.q1o4],
      correctAnswer: 2,
      explanation: quiz.q1a,
    },
    {
      question: quiz.q2,
      options: [quiz.q2o1, quiz.q2o2, quiz.q2o3, quiz.q2o4],
      correctAnswer: 0,
      explanation: quiz.q2a,
    },
    {
      question: quiz.q3,
      options: [quiz.q3o1, quiz.q3o2, quiz.q3o3, quiz.q3o4],
      correctAnswer: 3,
      explanation: quiz.q3a,
    },
    {
      question: quiz.q4,
      options: [quiz.q4o1, quiz.q4o2, quiz.q4o3, quiz.q4o4],
      correctAnswer: 2,
      explanation: quiz.q4a,
    },
  ]

  return <Quiz questions={questions} />
}
