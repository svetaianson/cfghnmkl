"use client"

import { Card } from "@/components/ui/card"
import { PieChart, Link2, Scale, Clock, Shield, Lightbulb } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function SmartPortfoliosLessonContent() {
  const { t } = useLanguage()
  const s = t.learning.levelUpLessons.smartPortfolios.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.whatIs}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.whatIsP1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.whatIsP2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyPrinciples}</h2>

        <div className="space-y-4">
          <div className="bg-white/5 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                <Link2 className="w-4 h-4 text-blue-500" />
              </div>
              <h3 className="text-lg font-semibold text-white">{s.assetCorrelation}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.assetCorrelationDesc}</p>
          </div>

          <div className="bg-white/5 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                <Scale className="w-4 h-4 text-green-500" />
              </div>
              <h3 className="text-lg font-semibold text-white">{s.positionSizing}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.positionSizingDesc}</p>
          </div>

          <div className="bg-white/5 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <Clock className="w-4 h-4 text-purple-500" />
              </div>
              <h3 className="text-lg font-semibold text-white">{s.timeDiversification}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.timeDiversificationDesc}</p>
          </div>

          <div className="bg-white/5 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-orange-500/20 flex items-center justify-center">
                <Shield className="w-4 h-4 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold text-white">{s.riskBalance}</h3>
            </div>
            <p className="text-white/70 text-sm">{s.riskBalanceDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-cyan-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
            <PieChart className="w-5 h-5 text-cyan-500" />
          </div>
          <h2 className="text-xl font-bold text-white">{s.samplePortfolio}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.samplePortfolioDesc}</p>
        <div className="space-y-3">
          <div className="flex items-center justify-between bg-white/5 rounded-lg p-3">
            <span className="text-white font-medium">{s.majorPairs}</span>
            <span className="text-purple-400 font-bold">{s.majorPairsAlloc}</span>
          </div>
          <div className="flex items-center justify-between bg-white/5 rounded-lg p-3">
            <span className="text-white font-medium">{s.minorPairs}</span>
            <span className="text-blue-400 font-bold">{s.minorPairsAlloc}</span>
          </div>
          <div className="flex items-center justify-between bg-white/5 rounded-lg p-3">
            <span className="text-white font-medium">{s.exoticPairs}</span>
            <span className="text-orange-400 font-bold">{s.exoticPairsAlloc}</span>
          </div>
          <div className="flex items-center justify-between bg-white/5 rounded-lg p-3">
            <span className="text-white font-medium">{s.goldCommodities}</span>
            <span className="text-yellow-400 font-bold">{s.goldCommoditiesAlloc}</span>
          </div>
        </div>
        <p className="text-white/60 text-sm mt-4">{s.samplePortfolioNote}</p>
      </Card>

      <Card className="border border-green-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <div className="flex items-center gap-3 mb-2">
          <Lightbulb className="w-5 h-5 text-green-400" />
          <h2 className="text-lg font-bold text-green-400">{s.proTip}</h2>
        </div>
        <p className="text-white/80 text-base leading-relaxed">{s.proTipText}</p>
      </Card>
    </div>
  )
}
