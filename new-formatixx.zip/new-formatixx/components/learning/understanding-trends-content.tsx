"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function UnderstandingTrendsContent() {
  const { t } = useLanguage()
  const s = t.learning.readingMarketLessons.trends.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.powerOfTrends}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.intro1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.intro2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.typesOfTrends}</h2>
        <div className="space-y-4">
          <div className="bg-green-600/10 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-green-300 mb-2">{s.uptrend}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-3">{s.uptrendDesc}</p>
            <p className="text-white/60 text-sm italic">{s.uptrendStrategy}</p>
          </div>
          <div className="bg-red-600/10 border border-red-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-red-300 mb-2">{s.downtrend}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-3">{s.downtrendDesc}</p>
            <p className="text-white/60 text-sm italic">{s.downtrendStrategy}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.sideways}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-3">{s.sidewaysDesc}</p>
            <p className="text-white/60 text-sm italic">{s.sidewaysStrategy}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.trendTimeframes}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.timeframesIntro}</p>
        <div className="space-y-3">
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.primaryTrend}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.primaryTrendDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.secondaryTrend}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.secondaryTrendDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.minorTrend}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.minorTrendDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.identifyingTrends}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.identifyIntro}</p>
        <div className="space-y-3">
          {[
            { label: s.higherHighs, desc: s.higherHighsDesc },
            { label: s.lowerHighs, desc: s.lowerHighsDesc },
            { label: s.trendlines, desc: s.trendlinesDesc },
            { label: s.movingAverages, desc: s.movingAveragesDesc },
            { label: s.volumeLabel, desc: s.volumeDesc },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
              <p className="text-white/80 text-base leading-relaxed">
                <span className="text-purple-300 font-semibold">{item.label}</span> {item.desc}
              </p>
            </div>
          ))}
        </div>
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-xl p-6 mt-6">
          <p className="text-white text-base leading-relaxed font-medium">{s.goldenRule}</p>
        </div>
      </Card>
    </div>
  )
}
