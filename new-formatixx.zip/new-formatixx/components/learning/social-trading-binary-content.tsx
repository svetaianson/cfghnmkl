"use client"

import { useLanguage } from "@/lib/i18n/language-context"

export function SocialTradingBinaryContent() {
  const { t } = useLanguage()
  const s = t.learning.lessons.socialTradingBinary.sections

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{s.intro}</h2>
        <p className="text-white/80 leading-relaxed mb-4">{s.subtitle}</p>
        <p className="text-white/80 leading-relaxed mb-4">{s.content1}</p>
        <div className="bg-purple-600/20 border border-purple-500/30 rounded-xl p-4 my-4">
          <p className="text-purple-300 font-semibold text-center">
            {s.essence}
          </p>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.oddsTitle}</h3>
        <div className="bg-[#1a0f2e]/60 border border-purple-500/30 rounded-xl p-4 my-4">
          <div className="space-y-2 text-white/80">
            <div className="flex justify-between">
              <span>{s.oddsPowerball}</span>
              <span className="text-red-400">1:175,000,000</span>
            </div>
            <div className="flex justify-between">
              <span>{s.oddsOscar}</span>
              <span className="text-red-400">1:1,700,000</span>
            </div>
            <div className="flex justify-between">
              <span>{s.oddsOlympic}</span>
              <span className="text-orange-400">1:660,000</span>
            </div>
            <div className="flex justify-between">
              <span>{s.oddsProAthlete}</span>
              <span className="text-orange-400">1:22,000</span>
            </div>
            <div className="flex justify-between">
              <span>{s.oddsMillionaire}</span>
              <span className="text-yellow-400">1:215</span>
            </div>
            <div className="flex justify-between">
              <span>{s.oddsBinaryTrading}</span>
              <span className="text-green-400">1:12</span>
            </div>
            <div className="flex justify-between font-semibold">
              <span>{s.oddsCopyTrading}</span>
              <span className="text-green-400">1:6</span>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.step1Title}</h3>
        <p className="text-white/80 leading-relaxed">
          {s.step1Desc}
        </p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.step2Title}</h3>
        <p className="text-white/80 leading-relaxed">
          {s.step2Desc}
        </p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.step3Title}</h3>
        <p className="text-white/80 leading-relaxed mb-4">
          {s.step3Desc}
        </p>
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 my-4">
          <p className="text-yellow-300 leading-relaxed">
            {s.step3Warning}
          </p>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.tipsTitle}</h3>
        <div className="space-y-4">
          <div className="bg-[#1a0f2e]/60 border border-purple-500/30 rounded-xl p-4">
            <p className="text-purple-400 font-semibold mb-2">{s.tip1Title}</p>
            <p className="text-white/80">{s.tip1Desc}</p>
          </div>

          <div className="bg-[#1a0f2e]/60 border border-purple-500/30 rounded-xl p-4">
            <p className="text-purple-400 font-semibold mb-2">{s.tip2Title}</p>
            <p className="text-white/80">{s.tip2Desc}</p>
          </div>

          <div className="bg-[#1a0f2e]/60 border border-purple-500/30 rounded-xl p-4">
            <p className="text-purple-400 font-semibold mb-2">{s.tip3Title}</p>
            <p className="text-white/80">{s.tip3Desc}</p>
          </div>

          <div className="bg-[#1a0f2e]/60 border border-purple-500/30 rounded-xl p-4">
            <p className="text-purple-400 font-semibold mb-2">{s.tip4Title}</p>
            <p className="text-white/80">{s.tip4Desc}</p>
          </div>

          <div className="bg-[#1a0f2e]/60 border border-purple-500/30 rounded-xl p-4">
            <p className="text-purple-400 font-semibold mb-2">{s.tip5Title}</p>
            <p className="text-white/80">{s.tip5Desc}</p>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.exampleTitle}</h3>
        <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
          <p className="text-white/80 leading-relaxed mb-2">
            {s.exampleDesc1}
          </p>
          <p className="text-white/80 leading-relaxed mb-2">
            {s.exampleDesc2}
          </p>
          <p className="text-green-300 leading-relaxed">
            {s.exampleProfit}
          </p>
        </div>
      </section>
    </div>
  )
}
