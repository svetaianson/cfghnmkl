"use client"

import { Card } from "@/components/ui/card"
import { Fuel, TrendingDown, TrendingUp, DollarSign } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function CrudeOilBinaryContent() {
  const { t } = useLanguage()
  const content = t.learning.moneyMakers.crudeOil.sections

  const impacts = [
    { icon: TrendingUp, title: content.exportingNations, description: content.exportingNationsDesc },
    { icon: TrendingDown, title: content.importingNations, description: content.importingNationsDesc },
    { icon: Fuel, title: content.inflationImpact, description: content.inflationImpactDesc },
    { icon: DollarSign, title: content.usdCorrelation, description: content.usdCorrelationDesc },
  ]

  const currencyPairs = [
    { pair: content.pair1, name: content.pair1Name, description: content.pair1Desc, color: "green" },
    { pair: content.pair2, name: content.pair2Name, description: content.pair2Desc, color: "blue" },
    { pair: content.pair3, name: content.pair3Name, description: content.pair3Desc, color: "purple" },
  ]

  const strategies = [
    content.strategy1,
    content.strategy2,
    content.strategy3,
    content.strategy4,
  ]

  return (
    <div className="space-y-8">
      {/* Introduction */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.worldCommodity}</h2>
        <p className="text-white/70 leading-relaxed mb-4">
          {content.intro1}
        </p>
        <p className="text-white/70 leading-relaxed">
          {content.intro2}
        </p>
      </section>

      {/* How Oil Affects Markets */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-6">{content.howAffects}</h2>
        <div className="space-y-4">
          {impacts.map((item, index) => {
            const Icon = item.icon
            return (
              <Card key={index} className="bg-purple-900/20 border-purple-500/30 p-5">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-orange-600/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-orange-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                    <p className="text-white/60 text-sm">{item.description}</p>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      </section>

      {/* Key Currency Pairs */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.keyPairs}</h2>
        <div className="space-y-4">
          {currencyPairs.map((item, index) => (
            <Card key={index} className="bg-purple-900/20 border-purple-500/30 p-5">
              <div className="flex items-start gap-4">
                <div className={`px-3 py-1 rounded-lg bg-${item.color}-600/20 border border-${item.color}-500/30`}>
                  <span className={`text-${item.color}-400 font-bold`}>{item.pair}</span>
                </div>
                <div>
                  <h4 className="text-white/80 text-sm mb-1">{item.name}</h4>
                  <p className="text-white/60 text-sm">{item.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Trading Strategies */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.tradingStrategies}</h2>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <ul className="space-y-3">
            {strategies.map((strategy, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="text-orange-400 font-bold">{index + 1}.</span>
                <span className="text-white/70">{strategy}</span>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      {/* Key Takeaway */}
      <section>
        <Card className="bg-[#1a1520] border-orange-500/30 p-6">
          <p className="text-white/70 leading-relaxed">
            {content.keyTakeaway}
          </p>
        </Card>
      </section>
    </div>
  )
}
