"use client"

import { BuyingSellingLessonContent } from "./buying-selling-lesson-content"

export function BuyingSellingContent() {
  return <BuyingSellingLessonContent />
}
