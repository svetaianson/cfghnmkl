"use client"

import { useLanguage } from "@/lib/i18n/language-context"

export function FromSimContent() {
  const { t } = useLanguage()
  const s = t.learning.levelUpLessons.fromSim.sections

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{s.mainTitle}</h2>
        <p className="text-white/80 leading-relaxed mb-4">{s.intro1}</p>
        <p className="text-white/80 leading-relaxed">{s.intro2}</p>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.popularPlatforms}</h3>

        <div className="space-y-4">
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h4 className="text-lg font-semibold text-white mb-2">{s.quotex}</h4>
            <p className="text-white/80 leading-relaxed mb-2">{s.quotexDesc}</p>
            <p className="text-purple-400 text-sm">{s.quotexBest}</p>
          </div>

          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h4 className="text-lg font-semibold text-white mb-2">{s.pocketOption}</h4>
            <p className="text-white/80 leading-relaxed mb-2">{s.pocketOptionDesc}</p>
            <p className="text-purple-400 text-sm">{s.pocketOptionBest}</p>
          </div>

          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h4 className="text-lg font-semibold text-white mb-2">{s.tradingView}</h4>
            <p className="text-white/80 leading-relaxed mb-2">{s.tradingViewDesc}</p>
            <p className="text-purple-400 text-sm">{s.tradingViewBest}</p>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.keyFeatures}</h3>

        <div className="space-y-4">
          <div>
            <h4 className="text-lg font-semibold text-white mb-2">{s.regulation}</h4>
            <p className="text-white/80 leading-relaxed">{s.regulationDesc}</p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-2">{s.lowSpreads}</h4>
            <p className="text-white/80 leading-relaxed">{s.lowSpreadsDesc}</p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-2">{s.fastExecution}</h4>
            <p className="text-white/80 leading-relaxed">{s.fastExecutionDesc}</p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-2">{s.educational}</h4>
            <p className="text-white/80 leading-relaxed">{s.educationalDesc}</p>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-3">{s.transition}</h3>
        <p className="text-white/80 leading-relaxed mb-4">{s.transitionP1}</p>
        <p className="text-white/80 leading-relaxed">{s.transitionP2}</p>
      </section>

      <section className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
        <h4 className="text-lg font-semibold text-purple-400 mb-2">{s.proTip}</h4>
        <p className="text-white/80 leading-relaxed">{s.proTipText}</p>
      </section>
    </div>
  )
}
