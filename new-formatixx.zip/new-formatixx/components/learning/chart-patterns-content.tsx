"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function ChartPatternsContent() {
  const { t } = useLanguage()
  const s = t.learning.readingMarketLessons.patterns.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.languageOfCharts}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.intro1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.intro2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.continuationPatterns}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.continuationIntro}</p>
        <div className="space-y-4">
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.flag}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-2">{s.flagDesc}</p>
            <p className="text-white/60 text-sm italic">{s.flagTrading}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.triangle}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-2">{s.triangleDesc}</p>
            <p className="text-white/60 text-sm italic">{s.triangleTrading}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.pennant}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-2">{s.pennantDesc}</p>
            <p className="text-white/60 text-sm italic">{s.pennantTrading}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.reversalPatterns}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.reversalIntro}</p>
        <div className="space-y-4">
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.headShoulders}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-2">{s.headShouldersDesc}</p>
            <p className="text-white/60 text-sm italic">{s.headShouldersTrading}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.inverseHS}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-2">{s.inverseHSDesc}</p>
            <p className="text-white/60 text-sm italic">{s.inverseHSTrading}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.doubleTopBottom}</h3>
            <p className="text-white/80 text-base leading-relaxed mb-2">{s.doubleTopBottomDesc}</p>
            <p className="text-white/60 text-sm italic">{s.doubleTopBottomTrading}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.tradingPrinciples}</h2>
        <div className="space-y-3">
          {[
            { label: s.waitConfirmation, desc: s.waitConfirmationDesc },
            { label: s.volumeMatters, desc: s.volumeMattersDesc },
            { label: s.measureTargets, desc: s.measureTargetsDesc },
            { label: s.useStopLosses, desc: s.useStopLossesDesc },
            { label: s.contextKey, desc: s.contextKeyDesc },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
              <p className="text-white/80 text-base leading-relaxed">
                <span className="text-purple-300 font-semibold">{item.label}</span> {item.desc}
              </p>
            </div>
          ))}
        </div>
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-xl p-6 mt-6">
          <p className="text-white text-base leading-relaxed font-medium">{s.remember}</p>
        </div>
      </Card>
    </div>
  )
}
