"use client"

import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function RiskManagementContent() {
  const { t } = useLanguage()
  const s = t.learning.protectLessons.riskManagement.sections

  return (
    <div className="space-y-6">
      {/* Why Critical */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.whyCritical}</h2>
        <p className="text-white/80 text-base leading-relaxed">
          {s.intro}
        </p>
      </Card>

      {/* The 1-2% Rule */}
      <Card className="border border-purple-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.onetwopercent}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.onetwopercentDesc}</p>
        <div className="bg-purple-600/10 border border-purple-600/30 rounded-lg p-4 space-y-3">
          <p className="font-semibold text-white">{s.goldenRule}</p>
          <p className="text-white/80"><strong>{s.exampleIntro}</strong></p>
          <ul className="list-disc pl-6 space-y-1 text-white/80">
            <li>{s.example1}</li>
            <li>{s.example2}</li>
          </ul>
          <p className="text-white/80">{s.surviveNote}</p>
        </div>
      </Card>

      {/* Position Sizing */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.positionSizing}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.positionSizingDesc}</p>
        <div className="bg-purple-600/10 border border-purple-600/30 rounded-lg p-4 space-y-3">
          <p className="font-semibold text-white">{s.formula}</p>
          <p className="font-mono text-sm text-white/80">{s.formulaText}</p>
          <p className="text-white/80"><strong>{s.formulaExample}</strong></p>
          <p className="text-white/80">{s.formulaExampleCalc}</p>
          <p className="text-white/80">{s.formulaResult}</p>
          <p className="text-white/80">{s.formulaTrade}</p>
        </div>
      </Card>

      {/* Risk-Reward Ratio */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.riskReward}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.riskRewardDesc}</p>
        <ul className="list-disc pl-6 space-y-2 text-white/80">
          <li><strong className="text-white">{s.ratio12}</strong> {s.ratio12Desc}</li>
          <li><strong className="text-white">{s.ratio13}</strong> {s.ratio13Desc}</li>
          <li><strong className="text-white">{s.ratio15}</strong> {s.ratio15Desc}</li>
        </ul>
        <p className="mt-3 text-green-400">{s.winRateNote}</p>
      </Card>

      {/* Essential Risk Rules */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.essentialRules}</h2>
        <ul className="list-disc pl-6 space-y-2 text-white/80">
          <li><strong className="text-white">{s.rule1Label}</strong> {s.rule1}</li>
          <li><strong className="text-white">{s.rule2Label}</strong> {s.rule2}</li>
          <li><strong className="text-white">{s.rule3Label}</strong> {s.rule3}</li>
          <li><strong className="text-white">{s.rule4Label}</strong> {s.rule4}</li>
          <li><strong className="text-white">{s.rule5Label}</strong> {s.rule5}</li>
          <li><strong className="text-white">{s.rule6Label}</strong> {s.rule6}</li>
        </ul>
      </Card>

      {/* Managing Open Trades */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.managingOpen}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.managingOpenDesc}</p>
        <ul className="list-disc pl-6 space-y-2 text-white/80">
          <li><strong className="text-white">{s.manage1Label}</strong> {s.manage1}</li>
          <li><strong className="text-white">{s.manage2Label}</strong> {s.manage2}</li>
          <li><strong className="text-white">{s.manage3Label}</strong> {s.manage3}</li>
          <li><strong className="text-white">{s.manage4Label}</strong> {s.manage4}</li>
        </ul>
      </Card>

      {/* Key Takeaways */}
      <Card className="border border-green-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyTakeaways}</h2>
        <ul className="space-y-3 text-white/80">
          {[s.takeaway1, s.takeaway2, s.takeaway3, s.takeaway4].map((item, idx) => (
            <li key={idx} className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
