"use client"

import { Card } from "@/components/ui/card"
import { Shield, TrendingUp, DollarSign, Coins } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function GoldBinaryContent() {
  const { t } = useLanguage()
  const content = t.learning.moneyMakers.gold.sections

  const reasons = [
    { icon: Shield, title: content.safeHaven, description: content.safeHavenDesc },
    { icon: TrendingUp, title: content.inflationHedge, description: content.inflationHedgeDesc },
    { icon: DollarSign, title: content.usdInverse, description: content.usdInverseDesc },
    { icon: Coins, title: content.commodityCurrencies, description: content.commodityCurrenciesDesc },
  ]

  const strategies = [
    { title: content.riskOff, description: content.riskOffDesc },
    { title: content.commodityCorrelation, description: content.commodityCorrelationDesc },
    { title: content.usdPlays, description: content.usdPlaysDesc },
  ]

  return (
    <div className="space-y-8">
      {/* Introduction */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.connection}</h2>
        <p className="text-white/70 leading-relaxed mb-4">
          {content.intro1}
        </p>
        <p className="text-white/70 leading-relaxed">
          {content.intro2}
        </p>
      </section>

      {/* Why Gold Matters */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-6">{content.whyMatters}</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {reasons.map((item, index) => {
            const Icon = item.icon
            return (
              <Card key={index} className="bg-purple-900/20 border-purple-500/30 p-5">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-yellow-600/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-yellow-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                    <p className="text-white/60 text-sm">{item.description}</p>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      </section>

      {/* Trading Strategies */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.tradingStrategies}</h2>
        <Card className="bg-[#1a1035] border-purple-500/30 p-6">
          <p className="text-white/70 leading-relaxed mb-4">
            {content.tradingStrategiesIntro}
          </p>
          <div className="space-y-3">
            {strategies.map((strategy, index) => (
              <div key={index} className="bg-purple-600/20 rounded-lg p-4 border border-purple-500/30">
                <h4 className="text-purple-300 font-semibold mb-1">{strategy.title}</h4>
                <p className="text-white/60 text-sm">{strategy.description}</p>
              </div>
            ))}
          </div>
        </Card>
      </section>

      {/* Key Takeaway */}
      <section>
        <h2 className="text-2xl font-bold text-white mb-4">{content.keyTakeaway}</h2>
        <Card className="bg-[#1a1520] border-yellow-500/30 p-6">
          <p className="text-white/70 leading-relaxed">
            {content.keyTakeawayContent}
          </p>
        </Card>
      </section>
    </div>
  )
}
