"use client"

import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

export function TradingStylesContent() {
  const { t } = useLanguage()
  const s = t.learning.executeLessons.tradingStyle.sections

  const styles = [
    {
      title: s.scalping,
      subtitle: s.scalpingSubtitle,
      fields: [
        { label: s.scalpingTimeframe, value: s.scalpingTimeframeVal },
        { label: s.scalpingDuration, value: s.scalpingDurationVal },
        { label: s.scalpingTarget, value: s.scalpingTargetVal },
        { label: s.scalpingBestFor, value: s.scalpingBestForVal },
        { label: s.scalpingPros, value: s.scalpingProsVal },
        { label: s.scalpingCons, value: s.scalpingConsVal },
      ],
    },
    {
      title: s.dayTrading,
      subtitle: s.dayTradingSubtitle,
      fields: [
        { label: s.dayTradingTimeframe, value: s.dayTradingTimeframeVal },
        { label: s.dayTradingDuration, value: s.dayTradingDurationVal },
        { label: s.dayTradingTarget, value: s.dayTradingTargetVal },
        { label: s.dayTradingBestFor, value: s.dayTradingBestForVal },
        { label: s.dayTradingPros, value: s.dayTradingProsVal },
        { label: s.dayTradingCons, value: s.dayTradingConsVal },
      ],
    },
    {
      title: s.swingTrading,
      subtitle: s.swingTradingSubtitle,
      fields: [
        { label: s.swingTradingTimeframe, value: s.swingTradingTimeframeVal },
        { label: s.swingTradingDuration, value: s.swingTradingDurationVal },
        { label: s.swingTradingTarget, value: s.swingTradingTargetVal },
        { label: s.swingTradingBestFor, value: s.swingTradingBestForVal },
        { label: s.swingTradingPros, value: s.swingTradingProsVal },
        { label: s.swingTradingCons, value: s.swingTradingConsVal },
      ],
    },
    {
      title: s.positionTrading,
      subtitle: s.positionTradingSubtitle,
      fields: [
        { label: s.positionTradingTimeframe, value: s.positionTradingTimeframeVal },
        { label: s.positionTradingDuration, value: s.positionTradingDurationVal },
        { label: s.positionTradingTarget, value: s.positionTradingTargetVal },
        { label: s.positionTradingBestFor, value: s.positionTradingBestForVal },
        { label: s.positionTradingPros, value: s.positionTradingProsVal },
        { label: s.positionTradingCons, value: s.positionTradingConsVal },
      ],
    },
  ]

  const questions = [
    { label: s.time, question: s.timeQ },
    { label: s.personality, question: s.personalityQ },
    { label: s.stress, question: s.stressQ },
    { label: s.capital, question: s.capitalQ },
    { label: s.goals, question: s.goalsQ },
  ]

  return (
    <div className="space-y-6">
      {/* Introduction */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.findingStyle}</h2>
        <p className="text-white/80 text-base leading-relaxed">
          {s.intro}
        </p>
      </Card>

      {/* Trading Styles */}
      {styles.map((style, idx) => (
        <Card key={idx} className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
          <h2 className="text-xl font-bold text-white mb-2">{style.title}</h2>
          <p className="font-semibold text-purple-400 mb-4">{style.subtitle}</p>
          <div className="space-y-2 text-white/80">
            {style.fields.map((field, i) => (
              <p key={i}>
                <strong className="text-white">{field.label}</strong> {field.value}
              </p>
            ))}
          </div>
        </Card>
      ))}

      {/* Choosing Your Style */}
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.choosingStyle}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.choosingStyleDesc}</p>
        <ul className="space-y-2 text-white/80">
          {questions.map((q, idx) => (
            <li key={idx}>
              <strong className="text-white">{q.label}</strong> {q.question}
            </li>
          ))}
        </ul>
      </Card>

      {/* Key Takeaways */}
      <Card className="border border-green-500/30 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.keyTakeaways}</h2>
        <ul className="space-y-3 text-white/80">
          {[s.takeaway1, s.takeaway2, s.takeaway3, s.takeaway4].map((item, idx) => (
            <li key={idx} className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
