"use client"

import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/i18n/language-context"

export function NavigatingChartsContent() {
  const { t } = useLanguage()
  const s = t.learning.readingMarketLessons.navigating.sections

  return (
    <div className="space-y-6">
      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.understandingCharts}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.intro1}</p>
        <p className="text-white/80 text-base leading-relaxed">{s.intro2}</p>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.typesOfCharts}</h2>
        <div className="space-y-4">
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.lineCharts}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.lineChartsDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.barCharts}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.barChartsDesc}</p>
          </div>
          <div className="bg-purple-600/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">{s.candlestickCharts}</h3>
            <p className="text-white/80 text-base leading-relaxed">{s.candlestickChartsDesc}</p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.timeframes}</h2>
        <p className="text-white/80 text-base leading-relaxed mb-4">{s.timeframesIntro}</p>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.shortTerm}</span> {s.shortTermDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.mediumTerm}</span> {s.mediumTermDesc}
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
            <p className="text-white/80 text-base leading-relaxed">
              <span className="text-purple-300 font-semibold">{s.longTerm}</span> {s.longTermDesc}
            </p>
          </div>
        </div>
      </Card>

      <Card className="border border-[#5F0BE8]/20 bg-[#1a0f2e]/60 backdrop-blur-sm p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">{s.readingAxes}</h2>
        <div className="space-y-3">
          <p className="text-white/80 text-base leading-relaxed">
            <span className="text-purple-300 font-semibold">{s.yAxis}</span> {s.yAxisDesc}
          </p>
          <p className="text-white/80 text-base leading-relaxed">
            <span className="text-purple-300 font-semibold">{s.xAxis}</span> {s.xAxisDesc}
          </p>
        </div>
        <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-xl p-6 mt-4">
          <p className="text-white text-base leading-relaxed font-medium">{s.proTip}</p>
        </div>
      </Card>
    </div>
  )
}
