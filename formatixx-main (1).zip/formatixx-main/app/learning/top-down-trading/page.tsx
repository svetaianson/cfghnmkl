"use client"

import { TopDownTradingContent } from "@/components/learning/top-down-trading-content"

export default function TopDownTradingPage() {
  return <TopDownTradingContent />
}
