"use client"

import { RSIContent } from "@/components/learning/rsi-content"

export default function RSIPage() {
  return <RSIContent />
}
