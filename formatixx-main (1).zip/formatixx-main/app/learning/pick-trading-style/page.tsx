"use client"

import { TradingStylesContent } from "@/components/learning/trading-styles-content"

export default function PickTradingStylePage() {
  return <TradingStylesContent />
}
