"use client"

import { MovingAverageContent } from "@/components/learning/moving-average-content"

export default function MovingAveragePage() {
  return <MovingAverageContent />
}
