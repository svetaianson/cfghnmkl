"use client"

import { VolumeIndicatorContent } from "@/components/learning/volume-indicator-content"

export default function VolumeIndicatorPage() {
  return <VolumeIndicatorContent />
}
