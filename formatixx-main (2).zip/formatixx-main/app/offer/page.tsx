import OfferPageClient from "./offer-client"

export default function OfferPage() {
  return <OfferPageClient />
}
