"use client"

import { RiskManagementContent } from "@/components/learning/risk-management-content"

export default function RiskManagementPage() {
  return <RiskManagementContent />
}
